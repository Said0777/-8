import 'package:get_it/get_it.dart';
import 'package:http/http.dart' as http;
import 'data/datasources/post_remote_datasource.dart';
import 'data/repositories/post_repository_impl.dart';
import 'domain/repositories/post_repository.dart';
import 'domain/usecases/get_posts.dart';
import 'presentation/bloc/post_bloc.dart';

final sl = GetIt.instance;

void init() {
  // Bloc
  sl.registerFactory(() => PostBloc(getPosts: sl()));

  // Use cases
  sl.registerLazySingleton(() => GetPosts(sl()));

  // Repositories
  sl.registerLazySingleton<PostRepository>(
    () => PostRepositoryImpl(sl()),
  );

  // Data sources
  sl.registerLazySingleton<PostRemoteDataSource>(
    () => PostRemoteDataSourceImpl(sl()),
  );

  // External dependencies
  sl.registerLazySingleton(() => http.Client());
}
