import 'package:flutter_bloc/flutter_bloc.dart';
import '../../domain/entities/post.dart';
import '../../domain/usecases/get_posts.dart';
import 'post_event.dart';
import 'post_state.dart';

class PostBloc extends Bloc<PostEvent, PostState> {
  final GetPosts getPosts;
  List<Post> _posts = [];

  PostBloc({required this.getPosts}) : super(PostInitialState()) {
    on<LoadPostsEvent>(_onLoad);
    on<ReloadPostsEvent>(_onReload);
    on<DeletePostEvent>(_onDelete);
    on<NavigateToDetailEvent>(_onNavigate);
  }

  Future<void> _onLoad(
    LoadPostsEvent event,
    Emitter<PostState> emit,
  ) async {
    emit(PostLoadingState());
    try {
      _posts = await getPosts();
      emit(PostLoadedState(List.from(_posts)));
    } catch (e) {
      emit(PostErrorState(e.toString()));
    }
  }

  Future<void> _onReload(
    ReloadPostsEvent event,
    Emitter<PostState> emit,
  ) async {
    emit(PostDeleteLoadingState(List.from(_posts)));
    try {
      _posts = await getPosts();
      emit(PostLoadedState(List.from(_posts)));
    } catch (e) {
      emit(PostErrorState(e.toString()));
    }
  }

  Future<void> _onDelete(
    DeletePostEvent event,
    Emitter<PostState> emit,
  ) async {
    emit(PostDeleteLoadingState(List.from(_posts)));
    await Future.delayed(const Duration(milliseconds: 500));
    _posts.removeAt(event.index);
    emit(PostLoadedState(List.from(_posts)));
  }

  Future<void> _onNavigate(
    NavigateToDetailEvent event,
    Emitter<PostState> emit,
  ) async {
    emit(PostNavigateToDetailState(
      posts: List.from(_posts),
      selectedPost: event.post,
    ));
    await Future.delayed(const Duration(milliseconds: 100));
    emit(PostLoadedState(List.from(_posts)));
  }
}
