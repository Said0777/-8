import '../../domain/entities/post.dart';

abstract class PostEvent {}

class LoadPostsEvent extends PostEvent {}

class ReloadPostsEvent extends PostEvent {}

class DeletePostEvent extends PostEvent {
  final int index;
  DeletePostEvent(this.index);
}

class NavigateToDetailEvent extends PostEvent {
  final Post post;
  NavigateToDetailEvent(this.post);
}
