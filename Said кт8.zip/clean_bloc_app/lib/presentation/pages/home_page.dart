import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/post_bloc.dart';
import '../bloc/post_event.dart';
import '../bloc/post_state.dart';
import 'detail_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Posts'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => context.read<PostBloc>().add(ReloadPostsEvent()),
        tooltip: 'Reload',
        child: const Icon(Icons.refresh),
      ),
      body: BlocConsumer<PostBloc, PostState>(
        listener: (context, state) {
          // Переход на другой экран через BlocConsumer listener
          if (state is PostNavigateToDetailState) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => DetailPage(post: state.selectedPost),
              ),
            );
          }
        },
        builder: (context, state) {
          if (state is PostLoadingState) {
            return const Center(child: CircularProgressIndicator());
          }

          if (state is PostErrorState) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error_outline, size: 48, color: Colors.red),
                  const SizedBox(height: 8),
                  Text('Ошибка: ${state.message}'),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () =>
                        context.read<PostBloc>().add(LoadPostsEvent()),
                    child: const Text('Повторить'),
                  ),
                ],
              ),
            );
          }

          if (state is PostLoadedState) {
            return Stack(
              children: [
                ListView.builder(
                  itemCount: state.posts.length,
                  itemBuilder: (context, index) {
                    final post = state.posts[index];
                    return ListTile(
                      leading: CircleAvatar(child: Text('${post.id}')),
                      title: Text(
                        post.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      subtitle: Text(
                        post.body,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      onTap: () => context
                          .read<PostBloc>()
                          .add(NavigateToDetailEvent(post)),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => context
                            .read<PostBloc>()
                            .add(DeletePostEvent(index)),
                      ),
                    );
                  },
                ),
                if (state is PostDeleteLoadingState)
                  const Center(child: CircularProgressIndicator()),
              ],
            );
          }

          return const SizedBox();
        },
      ),
    );
  }
}
