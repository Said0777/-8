# Clean Architecture + Bloc — Flutter App

Flutter приложение, демонстрирующее Clean Architecture с BLoC state management.

## Структура проекта

```
lib/
├── core/
│   └── error/
│       └── failures.dart          # Классы ошибок
├── data/
│   ├── datasources/
│   │   └── post_remote_datasource.dart  # Источник данных (HTTP)
│   ├── models/
│   │   └── post_model.dart        # Модель с fromJson
│   └── repositories/
│       └── post_repository_impl.dart    # Реализация репозитория
├── domain/
│   ├── entities/
│   │   └── post.dart              # Чистая сущность
│   ├── repositories/
│   │   └── post_repository.dart   # Абстракция репозитория
│   └── usecases/
│       └── get_posts.dart         # Use Case
├── presentation/
│   ├── bloc/
│   │   ├── post_bloc.dart         # Bloc
│   │   ├── post_event.dart        # События
│   │   └── post_state.dart        # Состояния
│   └── pages/
│       ├── home_page.dart         # Главный экран
│       └── detail_page.dart       # Экран деталей
├── injection_container.dart       # Dependency Injection (get_it)
└── main.dart
```

## Запуск

```bash
flutter pub get
flutter run
```

## Функционал

- Загрузка постов с сервера (jsonplaceholder.typicode.com)
- Перезагрузка данных (FAB кнопка)
- Удаление поста из списка
- Переход на экран деталей через `BlocConsumer`
